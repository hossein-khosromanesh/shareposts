<?php
  // DB Params
  define('DB_HOST', 'localhost');
  define('DB_USER', 'yourDbUsername');
  define('DB_PASS', 'yourDbPassword');
  define('DB_NAME', 'yourDbName');

  // App Root
  define('APPROOT', dirname(dirname(__FILE__)));
  // URL Root
  define('URLROOT', 'http://localhost/yourUrlRoot');
  // Site Name
  define('SITENAME', 'yourSiteName');
  // App Version
  define('APPVERSION', '1.0.0');
